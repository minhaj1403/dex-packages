##
## This script is sourced by /data/data/com.dex/files/usr/bin/login before executing shell.
##
