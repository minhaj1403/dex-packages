if [ ! -f /data/data/com.dex/files/home/.config/termux/termux.properties ] && [ ! -e /data/data/com.dex/files/home/.termux/termux.properties ]; then
	mkdir -p /data/data/com.dex/files/home/.termux
	cp /data/data/com.dex/files/usr/share/examples/termux/termux.properties /data/data/com.dex/files/home/.termux/
fi
