#!/data/data/com.dex/files/usr/bin/sh

echo "$@"
